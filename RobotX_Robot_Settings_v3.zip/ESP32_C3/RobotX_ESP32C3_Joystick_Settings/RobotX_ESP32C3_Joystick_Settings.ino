/*
  RobotX ESP32-C3 Wi-Fi UART Joystick
  -----------------------------------
  Создаёт веб-пульт управления и пересылает команды на Arduino Nano по UART.
  USB Serial на 115200 бод: настройка AP/STA, Wi-Fi и команды Nano.
  Настройки робота читаются из EEPROM Nano через UART RX GPIO5 (если подключён).
  При однопроводном UART используется локальная копия, без подтверждения записи.

  Важно для Arduino IDE / ESP32-C3: USB CDC On Boot -> Enabled
*/

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>

// =====================
// UART К ARDUINO NANO
// =====================
const int UART_TX_PIN = 4;   // ESP32-C3 TX -> Arduino Nano RX
const int UART_RX_PIN = 5;   // можно не подключать
const int UART_BAUD   = 9600;

// =====================
// WIFI / WEB
// =====================
Preferences prefs;
WebServer server(80);

String wifiMode = "AP";  // AP или STA

// SSID генерируется при запуске точки доступа из последних 4 HEX-символов AP MAC.
// Старое имя, сохранённое в NVS, больше не используется.
String apName = "";
String apPass = "12345678";

String staSsid = "";
String staPass = "";

bool useStaticIp = false;
String staticIp   = "192.168.1.77";
String gatewayIp  = "192.168.1.1";
String subnetMask = "255.255.255.0";
String dnsIp      = "8.8.8.8";

// =====================
// HTML СТРАНИЦА
// =====================
const char MAIN_page[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>RobotX Wi-Fi Joystick</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<style>
* {
  box-sizing: border-box;
  -webkit-tap-highlight-color: transparent;
}

html, body {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #101010;
  color: white;
  font-family: Arial, sans-serif;
  touch-action: manipulation;
  user-select: none;
}

body {
  display: flex;
  flex-direction: column;
}

.header {
  height: 72px;
  min-height: 72px;
  text-align: center;
  border-bottom: 1px solid #222;
  position: relative;
}

h1 {
  margin: 12px 0 4px 0;
  font-size: 28px;
}

.status {
  font-size: 20px;
  color: #aaa;
}

.status span {
  color: #f39c12;
  font-weight: bold;
}

.main {
  flex: 1;
  display: flex;
  width: 100%;
  min-height: 0;
  touch-action: none;
}

.panel {
  width: 50%;
  height: 100%;
  padding: 10px 32px 14px 32px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.leftPanel {
  border-right: 1px solid #252525;
}

.panelTitle {
  text-align: center;
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 14px;
}

.servoGrid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 22px 28px;
}

.driveGrid {
  width: 100%;
  max-width: 520px;
  margin: 0 auto;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 16px;
  align-items: center;
}

.btn {
  touch-action: none;
  height: 92px;
  border: none;
  border-radius: 20px;
  color: white;
  font-weight: bold;
  font-size: 30px;
  background: #2d89ef;
  box-shadow: 0 7px #14559b;
}

.btn:active {
  transform: translateY(5px);
  box-shadow: 0 2px #14559b;
  filter: brightness(0.9);
}

.servo {
  background: #f39c12;
  box-shadow: 0 7px #9a5f00;
}

.stop {
  background: #e74c3c;
  box-shadow: 0 7px #922b21;
}

.empty {
  visibility: hidden;
}

.smallText {
  display: block;
  margin-top: 6px;
  font-size: 14px;
  font-weight: normal;
  opacity: 0.9;
}

.footer {
  height: 42px;
  min-height: 42px;
  text-align: center;
  color: #999;
  font-size: 15px;
  border-top: 1px solid #222;
  padding-top: 4px;
}

@media (orientation: portrait) {
  .main {
    flex-direction: column;
  }

  .panel {
    width: 100%;
    height: 50%;
    padding: 8px 18px;
  }

  .leftPanel {
    border-right: none;
    border-bottom: 1px solid #252525;
  }

  .header {
    height: 66px;
    min-height: 66px;
  }

  h1 {
    font-size: 22px;
    margin-top: 8px;
  }

  .panelTitle {
    font-size: 19px;
    margin-bottom: 8px;
  }

  .btn {
    height: 62px;
    font-size: 24px;
    border-radius: 14px;
  }

  .smallText {
    display: none;
  }

  .footer {
    display: none;
  }
}

@media (max-height: 430px) and (orientation: landscape) {
  .header {
    height: 56px;
    min-height: 56px;
  }

  h1 {
    font-size: 24px;
    margin: 6px 0 2px 0;
  }

  .status {
    font-size: 17px;
  }

  .panel {
    padding: 6px 36px 8px 36px;
  }

  .panelTitle {
    font-size: 21px;
    margin-bottom: 8px;
  }

  .btn {
    height: 70px;
    font-size: 25px;
    border-radius: 17px;
    box-shadow: 0 5px #14559b;
  }

  .servo {
    box-shadow: 0 5px #9a5f00;
  }

  .stop {
    box-shadow: 0 5px #922b21;
  }

  .servoGrid {
    gap: 18px 26px;
  }

  .driveGrid {
    max-width: 470px;
    gap: 12px;
  }

  .smallText {
    font-size: 12px;
    margin-top: 3px;
  }

  .footer {
    height: 28px;
    min-height: 28px;
    font-size: 13px;
    padding-top: 2px;
  }
}

@media (max-height: 360px) and (orientation: landscape) {
  .header {
    height: 48px;
    min-height: 48px;
  }

  h1 {
    font-size: 20px;
    margin: 4px 0 0 0;
  }

  .status {
    font-size: 15px;
  }

  .panelTitle {
    display: none;
  }

  .btn {
    height: 58px;
    font-size: 22px;
    border-radius: 14px;
  }

  .smallText {
    display: none;
  }

  .footer {
    display: none;
  }
}

/* Settings popup / accessible in landscape and portrait */
.gear {position:absolute;right:12px;top:10px;border:1px solid #3a3d46;border-radius:12px;background:#222630;color:#fff;font-size:26px;width:52px;height:50px;cursor:pointer}
.gear:focus-visible,.btn:focus-visible {outline:3px solid #f6ab45;outline-offset:2px}
.modal {position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:50;display:none;align-items:center;justify-content:center;padding:12px;touch-action:pan-y}
.modal.open {display:flex}
.dialog {background:#1b1e27;border:1px solid #3b4050;border-radius:18px;padding:22px;max-height:94dvh;overflow-y:auto;width:min(520px,100%);box-shadow:0 20px 60px #0009;text-align:left;touch-action:pan-y}
.dialog h2 {margin:0 0 8px;font-size:23px}
.dialog p {font-size:13px;color:#b3b9c9;line-height:1.45;margin:6px 0 14px}
.fieldGrid {display:grid;grid-template-columns:1fr 1fr;gap:10px 14px}
.field label {display:block;font-size:13px;margin-bottom:5px;color:#d0d5df}
.field input {width:100%;height:43px;background:#11141c;color:#fff;border:1px solid #52596b;border-radius:9px;font:inherit;padding:0 10px;user-select:text;touch-action:manipulation}
.dialog .actions {display:flex;flex-wrap:wrap;gap:10px;margin-top:19px}
.dialog .actions button {border:1px solid #555e73;background:#292e3c;color:#fff;border-radius:10px;padding:12px 15px;font-size:14px;cursor:pointer}
.dialog .actions button.primary {background:#246dd1;border-color:#246dd1}
.dialog .actions button:disabled {opacity:.45}
#cfgMessage {min-height:22px;white-space:pre-wrap;font-size:13px;margin-top:12px;color:#aec0dc}
@media(max-width:400px){.dialog{padding:15px}.fieldGrid{gap:8px}.gear{height:40px;width:44px;top:7px;font-size:22px}}
</style>
</head>

<body>

<div class="header">
  <h1>RobotX Wi-Fi Joystick</h1>
  <button type="button" class="gear" id="settingsBtn" aria-label="Настройки робота" title="Настройки">⚙</button>
  <div class="status">Команда: <span id="status">S</span></div>
</div>

<div class="main">

  <div class="panel leftPanel">
    <div class="panelTitle">Сервоприводы</div>
    <div class="servoGrid">
      <button class="btn servo" data-cmd="Q">
        Q
        <span class="smallText">Левый вверх</span>
      </button>

      <button class="btn servo" data-cmd="W">
        W
        <span class="smallText">Правый вверх</span>
      </button>

      <button class="btn servo" data-cmd="A">
        A
        <span class="smallText">Левый вниз</span>
      </button>

      <button class="btn servo" data-cmd="D">
        D
        <span class="smallText">Правый вниз</span>
      </button>
    </div>
  </div>

  <div class="panel rightPanel">
    <div class="panelTitle">Движение</div>
    <div class="driveGrid">
      <div class="empty"></div>

      <button class="btn" data-cmd="F">
        ▲
        <span class="smallText">ВПЕРЕД</span>
      </button>

      <div class="empty"></div>

      <button class="btn" data-cmd="L">
        ◀
        <span class="smallText">ВЛЕВО</span>
      </button>

      <button class="btn stop" data-cmd="S">
        STOP
        <span class="smallText">СТОП</span>
      </button>

      <button class="btn" data-cmd="R">
        ▶
        <span class="smallText">ВПРАВО</span>
      </button>

      <div class="empty"></div>

      <button class="btn" data-cmd="B">
        ▼
        <span class="smallText">НАЗАД</span>
      </button>

      <div class="empty"></div>
    </div>
  </div>

</div>

<div class="footer">
  Движение: F/B/L/R, стоп: S. Сервы: Q/q, A/a, W/w, D/d
</div>

<div id="settingsModal" class="modal" role="dialog" aria-modal="true" aria-labelledby="settingsTitle">
  <div class="dialog">
    <h2 id="settingsTitle">⚙ Настройки робота</h2>
    <p>Параметры хранятся в EEPROM Arduino Nano. Коррекция действует только на правый мотор при движении прямо: плюс — быстрее, минус — медленнее.</p>
    <div class="fieldGrid">
      <div class="field"><label for="cfgSpeed">Скорость (0–255)</label><input id="cfgSpeed" type="number" min="0" max="255" step="1"></div>
      <div class="field"><label for="cfgTrim">Коррекция (−100…+100)</label><input id="cfgTrim" type="number" min="-100" max="100" step="1"></div>
      <div class="field"><label for="cfgLeftMin">Левая серва · мин (°)</label><input id="cfgLeftMin" type="number" min="0" max="175" step="1"></div>
      <div class="field"><label for="cfgLeftMax">Левая серва · макс (°)</label><input id="cfgLeftMax" type="number" min="5" max="180" step="1"></div>
      <div class="field"><label for="cfgRightMin">Правая серва · мин (°)</label><input id="cfgRightMin" type="number" min="0" max="175" step="1"></div>
      <div class="field"><label for="cfgRightMax">Правая серва · макс (°)</label><input id="cfgRightMax" type="number" min="5" max="180" step="1"></div>
    </div>
    <div id="cfgMessage" role="status"></div>
    <div class="actions">
      <button id="cfgRead" type="button">Обновить с Nano</button>
      <button id="cfgSave" type="button" class="primary">Сохранить в EEPROM</button>
      <button id="cfgClose" type="button">Закрыть</button>
    </div>
    <p style="margin-top:14px">Можно работать и с одним проводом ESP TX → Nano RX, но для чтения реальных параметров и подтверждения EEPROM подключите Nano TX (D1) → делитель 5 В/3,3 В → ESP GPIO5. Общая земля обязательна.</p>
  </div>
</div>
<script>
let lastCmd = '';
let busy = false;
const queue = [];
let activeButton = null;
const status = document.getElementById('status');
const modal = document.getElementById('settingsModal');
const keys = ['speed','trim','leftMin','leftMax','rightMin','rightMax'];
const inputIds = ['cfgSpeed','cfgTrim','cfgLeftMin','cfgLeftMax','cfgRightMin','cfgRightMax'];

// Ordered requests: motor commands supersede queued motor commands, but servo
// release (q/a/w/d) must NEVER be dropped, or the servo can stick active.
function sendCmd(cmd) {
  lastCmd=cmd; status.textContent=cmd;
  if('FBLRS'.includes(cmd) && cmd.length===1) {
    for(let i=queue.length-1;i>=0;i--)
      if('FBLRS'.includes(queue[i]))queue.splice(i,1);
  }
  queue.push(cmd);
  pump();
}
async function pump() {
  if(busy || !queue.length) return;
  busy=true;
  while (queue.length) {
    const cmd=queue.shift();
    try {
      const response=await fetch('/cmd?c='+encodeURIComponent(cmd),{cache:'no-store'});
      if(!response.ok) throw new Error('HTTP '+response.status);
    } catch(e) {status.textContent='НЕТ СВЯЗИ';}
  }
  busy=false;
}
function releaseCode(cmd) {
  const pairs={Q:'q',A:'a',W:'w',D:'d'};
  return pairs[cmd] || 'S';
}
function releaseActive() {
  if(activeButton) {
    const cmd=activeButton.dataset.cmd;
    activeButton=null;
    sendCmd(releaseCode(cmd));
  }
}
document.querySelectorAll('button[data-cmd]').forEach(btn=>{
  btn.addEventListener('pointerdown',e=>{
    if(modal.classList.contains('open')) return;
    e.preventDefault();
    if(activeButton && activeButton!==btn) releaseActive();
    activeButton=btn;
    try{btn.setPointerCapture(e.pointerId)}catch(_){}
    sendCmd(btn.dataset.cmd);
  });
  btn.addEventListener('pointerup',e=>{e.preventDefault();if(activeButton===btn)releaseActive()});
  btn.addEventListener('pointercancel',()=>{if(activeButton===btn)releaseActive()});
  btn.addEventListener('lostpointercapture',()=>{if(activeButton===btn)releaseActive()});
});
const keyboard={ArrowUp:'F',ArrowDown:'B',ArrowLeft:'L',ArrowRight:'R',' ':'S',q:'Q',a:'A',w:'W',d:'D'};
let pressedKey=null;
document.addEventListener('keydown',e=>{
  if(modal.classList.contains('open')||e.target.tagName==='INPUT')return;
  const cmd=keyboard[e.key];
  if(!cmd) return;
  e.preventDefault();
  if(pressedKey===e.key)return;
  if(pressedKey)sendCmd(releaseCode(keyboard[pressedKey]));
  pressedKey=e.key;
  sendCmd(cmd);
});
document.addEventListener('keyup',e=>{
  if(pressedKey!==e.key)return;
  e.preventDefault();
  sendCmd(releaseCode(keyboard[e.key]));
  pressedKey=null;
});
window.addEventListener('blur',()=>{releaseActive(); if(pressedKey){sendCmd('S');pressedKey=null;}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){releaseActive();sendCmd('S')}});
document.addEventListener('contextmenu',e=>e.preventDefault());

function cfgMessage(text,isError=false) {
  const node=document.getElementById('cfgMessage');
  node.textContent=text;
  node.style.color=isError?'#ff8f88':'#aec0dc';
}
function cfgBusy(value) {
  document.getElementById('cfgRead').disabled=value;
  document.getElementById('cfgSave').disabled=value;
}
async function readSettings() {
  cfgBusy(true); cfgMessage('Чтение параметров из Arduino Nano…');
  try {
    const response=await fetch('/api/settings',{cache:'no-store'});
    const body=await response.json();
    if(!response.ok)throw new Error(body.error||'Нет ответа от Nano');
    keys.forEach((name,i)=>document.getElementById(inputIds[i]).value=body[name]);
    cfgMessage(body.verified ? 'Параметры получены из EEPROM Nano.' :
      'Нет обратного UART: показана локальная копия ESP (может отличаться от EEPROM Nano).');
  } catch(e) {cfgMessage('Ошибка: '+e.message,true)}
  finally{cfgBusy(false)}
}
function validateSettings() {
  const result={};
  keys.forEach((name,i)=>{
    const input=document.getElementById(inputIds[i]);
    if(input.value.trim()===''||!Number.isInteger(Number(input.value)))throw new Error('Введите целое число: '+name);
    result[name]=Number(input.value);
  });
  if(result.speed<0||result.speed>255||result.trim<-100||result.trim>100 ||
    result.leftMin<0||result.leftMax>180||result.leftMin+5>result.leftMax ||
    result.rightMin<0||result.rightMax>180||result.rightMin+5>result.rightMax)
    throw new Error('Проверьте диапазоны и минимальный зазор углов 5°.');
  return result;
}
async function saveSettings() {
  try {
    const values=validateSettings();
    cfgBusy(true);cfgMessage('Отправка и запись в EEPROM…');
    const response=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(values)});
    const body=await response.json();
    if(!response.ok)throw new Error(body.error||'Не удалось сохранить');
    cfgMessage(body.verified ?
      'Сохранено в EEPROM Nano (подтверждено Arduino).' :
      'Команды записи отправлены в Nano, копия сохранена в ESP. Без Nano TX → GPIO5 запись не подтверждена!');
  } catch(e) {cfgMessage('Ошибка: '+e.message,true)}
  finally{cfgBusy(false)}
}
document.getElementById('settingsBtn').addEventListener('click',()=>{
  releaseActive();sendCmd('S');
  modal.classList.add('open');
  readSettings();
});
document.getElementById('cfgRead').addEventListener('click',readSettings);
document.getElementById('cfgSave').addEventListener('click',saveSettings);
document.getElementById('cfgClose').addEventListener('click',()=>{modal.classList.remove('open');sendCmd('S')});
modal.addEventListener('pointerdown',e=>{if(e.target===modal){modal.classList.remove('open');sendCmd('S')}});
</script>

</body>
</html>
)rawliteral";

// =====================
// NVS: ЗАГРУЗКА
// =====================
void loadSettings() {
  prefs.begin("robotx", true);

  wifiMode = prefs.getString("wifi_mode", "AP");

  // Имя AP не загружаем из NVS: оно всегда уникально для каждой платы.
  apPass = prefs.getString("ap_pass", "12345678");

  staSsid = prefs.getString("sta_ssid", "");
  staPass = prefs.getString("sta_pass", "");

  useStaticIp = prefs.getBool("use_static", false);
  staticIp   = prefs.getString("static_ip", "192.168.1.77");
  gatewayIp  = prefs.getString("gateway_ip", "192.168.1.1");
  subnetMask = prefs.getString("subnet", "255.255.255.0");
  dnsIp      = prefs.getString("dns", "8.8.8.8");

  prefs.end();

  wifiMode.toUpperCase();

  if (wifiMode != "AP" && wifiMode != "STA") {
    wifiMode = "AP";
  }

  if (apPass.length() < 8) {
    apPass = "12345678";
  }
}

// =====================
// NVS: СОХРАНЕНИЕ
// =====================
void saveStringSetting(const char* key, String value) {
  value.trim();
  prefs.begin("robotx", false);
  prefs.putString(key, value);
  prefs.end();
}

void saveBoolSetting(const char* key, bool value) {
  prefs.begin("robotx", false);
  prefs.putBool(key, value);
  prefs.end();
}

// =====================
// ОТПРАВКА КОМАНДЫ В NANO
// =====================
void sendToNano(String cmd) {
  cmd.trim();
  if (cmd.length() == 0) return;

  // Movement commands do not produce repetitive USB debug output.
  Serial1.print(cmd);
  Serial1.print('\n');
}

// =====================
// WIFI: УНИКАЛЬНОЕ ИМЯ AP
// =====================
String makeApName() {
  // Используем MAC именно точки доступа, а не STA-интерфейса.
  // Например, AA:BB:CC:DD:12:AF -> Znatok_pult_12AF.
  String mac = WiFi.softAPmacAddress();
  mac.replace(":", "");
  mac.toUpperCase();

  if (mac.length() != 12 || mac == "000000000000") {
    Serial.print("[WIFI] Invalid AP MAC: ");
    Serial.println(mac);
    return "";
  }

  return "Znatok_pult_" + mac.substring(mac.length() - 4);
}

bool startAccessPoint() {
  WiFi.mode(WIFI_AP);
  delay(100);
  WiFi.setTxPower(WIFI_POWER_8_5dBm);

  apName = makeApName();
  if (apName.isEmpty()) {
    Serial.println("[WIFI] AP not started: MAC unavailable");
    return false;
  }

  bool ok = WiFi.softAP(apName.c_str(), apPass.c_str());
  Serial.print("[WIFI] AP MAC: ");
  Serial.println(WiFi.softAPmacAddress());
  return ok;
}

// =====================
// WIFI START
// =====================
void startWiFi() {
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(1000);

  if (wifiMode == "AP") {
    bool ok = startAccessPoint();

    Serial.print("TX Power = ");
    Serial.println((int)WiFi.getTxPower());

    Serial.println();
    Serial.println("========== WIFI AP ==========");
    Serial.print("AP status: ");
    Serial.println(ok ? "OK" : "ERROR");
    Serial.print("SSID: ");
    Serial.println(apName);
    Serial.print("PASS: ");
    Serial.println(apPass);
    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());
    Serial.println("=============================");

    return;
  }

  if (wifiMode == "STA") {
    WiFi.mode(WIFI_STA);
    delay(100);

    WiFi.setTxPower(WIFI_POWER_8_5dBm);

    Serial.print("TX Power = ");
    Serial.println((int)WiFi.getTxPower());

    if (staSsid.length() == 0) {
      Serial.println("STA SSID is empty!");
      Serial.println("Fallback to AP mode.");

      bool apOk = startAccessPoint();
      Serial.print("Fallback AP status: ");
      Serial.println(apOk ? "OK" : "ERROR");

      Serial.print("Fallback AP SSID: ");
      Serial.println(apName);
      Serial.print("Fallback AP IP: ");
      Serial.println(WiFi.softAPIP());
      return;
    }

    Serial.println();
    Serial.println("========== WIFI STA ==========");
    Serial.print("Connecting to: ");
    Serial.println(staSsid);

    // Если включён статический IP, применяем его ДО WiFi.begin().
    // В исходной версии параметры SETSTATIC сохранялись в NVS, но фактически не применялись.
    if (useStaticIp) {
      IPAddress ip;
      IPAddress gateway;
      IPAddress subnet;
      IPAddress dns;

      bool ipOk = ip.fromString(staticIp);
      bool gatewayOk = gateway.fromString(gatewayIp);
      bool subnetOk = subnet.fromString(subnetMask);
      bool dnsOk = dns.fromString(dnsIp);

      if (ipOk && gatewayOk && subnetOk && dnsOk) {
        bool configOk = WiFi.config(ip, gateway, subnet, dns);
        Serial.print("Static IP config: ");
        Serial.println(configOk ? "OK" : "ERROR");
      } else {
        Serial.println("Static IP config skipped: bad saved IP settings");
      }
    }

    WiFi.begin(staSsid.c_str(), staPass.c_str());

    unsigned long startTime = millis();

    while (WiFi.status() != WL_CONNECTED && millis() - startTime < 15000) {
      delay(500);
      Serial.print(".");
    }

    Serial.println();

    if (WiFi.status() == WL_CONNECTED) {
      Serial.println("Connected!");
      Serial.print("IP: ");
      Serial.println(WiFi.localIP());
    } else {
      Serial.println("STA connection failed!");
      Serial.println("Fallback to AP mode.");

      WiFi.disconnect(true);
      WiFi.mode(WIFI_OFF);
      delay(500);

      bool apOk = startAccessPoint();
      Serial.print("Fallback AP status: ");
      Serial.println(apOk ? "OK" : "ERROR");

      Serial.print("Fallback AP SSID: ");
      Serial.println(apName);
      Serial.print("Fallback AP IP: ");
      Serial.println(WiFi.softAPIP());
    }
  }
}

// =====================
// ROBOT SETTINGS: bidirectional UART, read/write Nano EEPROM
// =====================
// A feedback wire is required: Nano TX D1 -> 5V/3.3V level shifter -> ESP GPIO5.
String nanoRxLine;
String requestNano(const String& cmd, const char *prefix, uint32_t timeoutMs = 450) {
  nanoRxLine = "";
  // Discard any earlier response before issuing a request (single outstanding request).
  while(Serial1.available()) Serial1.read();
  Serial1.print(cmd); Serial1.print('\n');
  const uint32_t start=millis();
  while ((uint32_t)(millis()-start)<timeoutMs) {
    while (Serial1.available()) {
      char c=(char)Serial1.read();
      if (c=='\n' || c=='\r') {
        if(nanoRxLine.startsWith(prefix)) return nanoRxLine;
        if(nanoRxLine.startsWith("ERR")) return nanoRxLine;
        nanoRxLine="";
      } else if (c>=32 && c<127 && nanoRxLine.length()<100) {
        nanoRxLine += c;
      }
    }
    delay(1); // yield to the ESP WiFi task
  }
  return "";
}

bool parseNanoCfg(const String &line, int values[6]) {
  if (!line.startsWith("CFG,")) return false;
  int begin=4;
  for (int i=0; i<6; i++) {
    int end=(i==5)?line.length():line.indexOf(',',begin);
    if (end<0 || end<=begin) return false;
    String part=line.substring(begin,end);
    for(unsigned int k=0;k<part.length();k++) {
      char ch=part[k];
      if (!((ch>='0'&&ch<='9')||(k==0 && ch=='-'))) return false;
    }
    values[i]=part.toInt();
    begin=end+1;
  }
  return true;
}

String robotSettingsJson(const int v[6], bool verified) {
  String out="{\"speed\":"+String(v[0]);
  out+=",\"trim\":"+String(v[1]);
  out+=",\"leftMin\":"+String(v[2]);
  out+=",\"leftMax\":"+String(v[3]);
  out+=",\"rightMin\":"+String(v[4]);
  out+=",\"rightMax\":"+String(v[5]);
  out+=verified ? ",\"verified\":true}" : ",\"verified\":false}";
  return out;
}

// ESP-side cache enables setup with only ESP TX -> Nano RX.
// Cache is NOT evidence of Nano EEPROM contents; verified flag is always false.
void cachedRobotSettings(int v[6]) {
  Preferences cp;
  cp.begin("robotcfg",true);
  String saved=cp.getString("last","160,0,0,180,0,180");
  cp.end();
  if(!parseNanoCfg("CFG,"+saved,v)) {
    v[0]=160;v[1]=0;v[2]=0;v[3]=180;v[4]=0;v[5]=180;
  }
}
void saveRobotCache(const int v[6]) {
  String value=String(v[0]);
  for(int i=1;i<6;i++) value+=","+String(v[i]);
  Preferences cp;
  cp.begin("robotcfg",false);
  cp.putString("last",value);
  cp.end();
}

void sendApiError(int code, const String &message) {
  server.send(code,"application/json; charset=utf-8", "{\"error\":\""+message+"\"}");
}

void handleGetRobotSettings() {
  sendToNano("S");
  String line=requestNano("CFG?","CFG,");
  int v[6];
  const bool verified=parseNanoCfg(line,v);
  if(!verified) cachedRobotSettings(v);
  server.send(200,"application/json; charset=utf-8",robotSettingsJson(v,verified));
}

void handleSaveRobotSettings() {
  const char *names[6]={"speed","trim","leftMin","leftMax","rightMin","rightMax"};
  int v[6];
  for (int i=0;i<6;i++) {
    if (!server.hasArg(names[i])) {sendApiError(400,"Не все поля заполнены");return;}
    String raw=server.arg(names[i]);
    if (raw.length()==0 || raw.length()>5) {sendApiError(400,"Неверное число");return;}
    for(unsigned int j=0;j<raw.length();j++) {
      char c=raw[j];
      if (!((c>='0'&&c<='9') || (j==0&&c=='-'))) {sendApiError(400,"Неверное число");return;}
    }
    v[i]=raw.toInt();
  }
  if(v[0]<0||v[0]>255||v[1]<-100||v[1]>100||
     v[2]<0||v[3]>180||v[2]+5>v[3]||
     v[4]<0||v[5]>180||v[4]+5>v[5]) {
    sendApiError(400,"Параметры вне диапазона");return;
  }
  sendToNano("S");
  String cfg="CFG";
  for(int i=0;i<6;i++) cfg+=","+String(v[i]);
  String reply=requestNano(cfg,"CFG,");
  int confirmation[6];
  const bool cfgVerified=parseNanoCfg(reply,confirmation);
  if (reply.startsWith("ERR")) {
    sendApiError(502,"Arduino Nano отклонил значения");return;
  }
  if(cfgVerified) {
    for(int i=0;i<6;i++) if(confirmation[i]!=v[i]) {
      sendApiError(502,"Arduino Nano вернул другие значения");return;
    }
  }
  reply=requestNano("COMMIT","SAVED",650);
  if(reply.startsWith("ERR")) {
    sendApiError(502,"Ошибка записи EEPROM на Arduino Nano");return;
  }
  const bool verified=(cfgVerified && reply=="SAVED");
  saveRobotCache(v);
  server.send(200,"application/json; charset=utf-8",verified ?
      "{\"ok\":true,\"verified\":true}" :
      "{\"ok\":true,\"verified\":false}");
}

// Forward Nano ACK/CFG replies to ESP USB when not handling HTTP settings.
String nanoLiveLine;
void forwardNanoReplies() {
  while(Serial1.available()) {
    char c=(char)Serial1.read();
    if(c=='\r'||c=='\n') {
      if(nanoLiveLine.length()) {Serial.print("[NANO] "); Serial.println(nanoLiveLine); nanoLiveLine="";}
    } else if(c>=32 && c<127 && nanoLiveLine.length()<100) nanoLiveLine+=c;
  }
}

// =====================
// WEB ОБРАБОТЧИКИ
// =====================
void handleRoot() {
  server.send_P(200, "text/html", MAIN_page);
}

void handleCommand() {
  if (!server.hasArg("c")) {
    server.send(400, "text/plain", "No command");
    return;
  }

  String cmd = server.arg("c");
  sendToNano(cmd);

  server.send(200, "text/plain", "OK");
}

void handleInfo() {
  String currentIp = "";

  if (WiFi.getMode() == WIFI_AP) {
    currentIp = WiFi.softAPIP().toString();
  } else {
    currentIp = WiFi.localIP().toString();
  }

  String info = "";
  info += "RobotX ESP32-C3 WiFi UART Bridge\n";
  info += "Mode: " + wifiMode + "\n";
  info += "AP SSID: " + apName + "\n";
  info += "STA SSID: " + staSsid + "\n";
  info += "Current IP: " + currentIp + "\n";
  info += "UART TX: GPIO4\n";
  info += "UART RX: GPIO5\n";
  info += "UART baud: 9600\n";

  server.send(200, "text/plain", info);
}

// =====================
// USB SERIAL КОМАНДЫ
// =====================
void printHelp() {
  Serial.println();
  Serial.println("========== COMMANDS ==========");
  Serial.println("INFO");
  Serial.println("SETMODE AP");
  Serial.println("SETMODE STA");
  Serial.println("SETAP 12345678    (change AP password, SSID is automatic)");
  Serial.println("SETSTA MyWiFi mypassword");
  Serial.println("SETDHCP");
  Serial.println("SETSTATIC 192.168.1.77 192.168.1.1 255.255.255.0 8.8.8.8");
  Serial.println("REBOOT");
  Serial.println("ROBOT: F B L R S Q q A a W w D d");
  Serial.println("SPEED: V160 (0..255), V? or ?");
  Serial.println("EEPROM: CFG? | CFG,160,0,0,180,0,180 | COMMIT");
  Serial.println("==============================");
}

void handleUsbSerial() {
  if (!Serial.available()) return;

  String cmd = Serial.readStringUntil('\n');
  cmd.trim();

  // PC can control the robot through the ESP32-C3 USB Serial as well.
  // The ESP32 is the only electrical UART transmitter into the Nano RX.
  // All existing one-letter controls are accepted, plus V0..V255 and V?.
  const String controls = "FBLRSQqAaWwDd?";
  bool robotCommand = cmd.length() == 1 && controls.indexOf(cmd.charAt(0)) >= 0;
  if (cmd.length() >= 2 && (cmd.charAt(0) == 'V' || cmd.charAt(0) == 'v')) {
    String value = cmd.substring(1);
    if (value == "?") {
      robotCommand = true;
    } else if (value.length() >= 1 && value.length() <= 3) {
      bool allDigits = true;
      for (unsigned int i = 0; i < value.length(); ++i) {
        if (value.charAt(i) < '0' || value.charAt(i) > '9') {
          allDigits = false;
          break;
        }
      }
      robotCommand = allDigits && value.toInt() <= 255;
    }
  }
  if (cmd == "CFG?" || cmd == "COMMIT" || cmd.startsWith("CFG,")) robotCommand=true;
  if (robotCommand) {
    sendToNano(cmd);
    return;
  }

  if (cmd == "INFO") {
    String currentIp = "";

    if (WiFi.getMode() == WIFI_AP) {
      currentIp = WiFi.softAPIP().toString();
    } else {
      currentIp = WiFi.localIP().toString();
    }

    Serial.println("========== INFO ==========");
    Serial.print("Mode: ");
    Serial.println(wifiMode);

    Serial.print("AP SSID: ");
    Serial.println(apName);
    Serial.print("AP PASS: ");
    Serial.println(apPass);

    Serial.print("STA SSID: ");
    Serial.println(staSsid);
    Serial.print("STA PASS: ");
    Serial.println(staPass);

    Serial.print("Use static IP: ");
    Serial.println(useStaticIp ? "YES" : "NO");

    Serial.print("Static IP: ");
    Serial.println(staticIp);
    Serial.print("Gateway: ");
    Serial.println(gatewayIp);
    Serial.print("Subnet: ");
    Serial.println(subnetMask);
    Serial.print("DNS: ");
    Serial.println(dnsIp);

    Serial.print("Current IP: ");
    Serial.println(currentIp);

    Serial.println("==========================");
    return;
  }

  if (cmd == "REBOOT") {
    Serial.println("Rebooting...");
    delay(500);
    ESP.restart();
    return;
  }

  if (cmd == "HELP") {
    printHelp();
    return;
  }

  if (cmd == "SETMODE AP") {
    saveStringSetting("wifi_mode", "AP");
    wifiMode = "AP";
    Serial.println("OK. Mode saved: AP. Use REBOOT.");
    return;
  }

  if (cmd == "SETMODE STA") {
    saveStringSetting("wifi_mode", "STA");
    wifiMode = "STA";
    Serial.println("OK. Mode saved: STA. Use REBOOT.");
    return;
  }

  if (cmd.startsWith("SETAP ")) {
    String args = cmd.substring(6);
    args.trim();

    // Новый формат: SETAP password
    // Для совместимости старый SETAP old_name password тоже принимается,
    // но имя игнорируется: SSID всегда получается из MAC.
    int separator = args.lastIndexOf(' ');
    String pass = separator < 0 ? args : args.substring(separator + 1);

    if (pass.length() < 8) {
      Serial.println("ERROR. Use: SETAP 12345678 (min. 8 chars)");
      return;
    }

    saveStringSetting("ap_pass", pass);
    apPass = pass;

    Serial.println("OK. AP password saved. SSID is automatic. Use REBOOT.");
    return;
  }

  if (cmd.startsWith("SETSTA ")) {
    int p1 = cmd.indexOf(' ', 7);

    if (p1 < 0) {
      Serial.println("ERROR. Use: SETSTA MyWiFi mypassword");
      return;
    }

    String ssid = cmd.substring(7, p1);
    String pass = cmd.substring(p1 + 1);

    saveStringSetting("sta_ssid", ssid);
    saveStringSetting("sta_pass", pass);

    staSsid = ssid;
    staPass = pass;

    Serial.println("OK. STA settings saved. Use REBOOT.");
    return;
  }

  if (cmd == "SETDHCP") {
    saveBoolSetting("use_static", false);
    useStaticIp = false;
    Serial.println("OK. DHCP enabled. Use REBOOT.");
    return;
  }

  if (cmd.startsWith("SETSTATIC ")) {
    String rest = cmd.substring(10);
    rest.trim();

    int p1 = rest.indexOf(' ');
    int p2 = rest.indexOf(' ', p1 + 1);
    int p3 = rest.indexOf(' ', p2 + 1);

    if (p1 < 0 || p2 < 0 || p3 < 0) {
      Serial.println("ERROR. Use:");
      Serial.println("SETSTATIC 192.168.1.77 192.168.1.1 255.255.255.0 8.8.8.8");
      return;
    }

    String ip      = rest.substring(0, p1);
    String gateway = rest.substring(p1 + 1, p2);
    String subnet  = rest.substring(p2 + 1, p3);
    String dns     = rest.substring(p3 + 1);

    IPAddress testIp, testGateway, testSubnet, testDns;

    if (!testIp.fromString(ip) ||
        !testGateway.fromString(gateway) ||
        !testSubnet.fromString(subnet) ||
        !testDns.fromString(dns)) {
      Serial.println("ERROR. Bad IP format.");
      return;
    }

    saveStringSetting("static_ip", ip);
    saveStringSetting("gateway_ip", gateway);
    saveStringSetting("subnet", subnet);
    saveStringSetting("dns", dns);
    saveBoolSetting("use_static", true);

    staticIp = ip;
    gatewayIp = gateway;
    subnetMask = subnet;
    dnsIp = dns;
    useStaticIp = true;

    Serial.println("OK. Static IP saved. Use REBOOT.");
    return;
  }

  Serial.println("Unknown command.");
  printHelp();
}

// =====================
// SETUP
// =====================
void setup() {
  Serial.begin(115200);
  Serial.setTimeout(20);
  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println("RobotX ESP32-C3 WiFi Joystick");
  Serial.println("AP / STA mode + NVS settings");
  Serial.println("================================");

  loadSettings();

  Serial1.begin(UART_BAUD, SERIAL_8N1, UART_RX_PIN, UART_TX_PIN);

  Serial.println("[UART] Started");
  Serial.println("[UART] TX = GPIO4");
  Serial.println("[UART] RX = GPIO5");

  startWiFi();

  server.on("/", handleRoot);
  server.on("/cmd", handleCommand);
  server.on("/info", handleInfo);
  server.on("/api/settings", HTTP_GET, handleGetRobotSettings);
  server.on("/api/settings", HTTP_POST, handleSaveRobotSettings);

  server.begin();

  Serial.println("[WEB] Server started");
  Serial.println("Open current device IP in browser.");
  printHelp();
}

// =====================
// LOOP
// =====================
void loop() {
  server.handleClient();
  handleUsbSerial();
  forwardNanoReplies();
}