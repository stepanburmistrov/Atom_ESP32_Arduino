/*
 RobotX / Arduino Nano / 2x TA6586 / EEPROM settings
 Robot wiring: LEFT D8/D9 (PB0/PB1), RIGHT D5/D6 (PD5/PD6)
 Servo LEFT A4, RIGHT D7. UART 9600, ESP TX GPIO4 -> Nano RX D0.
 Timer0 millis/micros; Timer1 Arduino Servo; Timer2 976 Hz 2-channel coast PWM.

 ASCII protocol (newline except single-letter movement/servo commands):
 F B L R S ; Q q A a W w D d
 V160           change RAM speed only (0..255)
 CFG?           -> CFG,<speed>,<trim>,<leftMin>,<leftMax>,<rightMin>,<rightMax>
 CFG,160,0,0,180,0,180     apply all fields to RAM only (echo CFG...)
 COMMIT         save all settings to Nano EEPROM (reply SAVED)
 ? or V?        legacy SPEED=<number>

 trim: signed correction applied ONLY to right motor during straight F/B.
 +trim makes right faster; -trim makes right slower. Range -100..+100.
 The PWM never enters IN1=1,IN2=1 (TA6586 brake); it coasts with 0/0.
 Ramp is intentionally SLOW: 5 duty steps per 5ms (previous stable build).
 No periodic debug output. Motor stop S is immediate.
*/
#include <Arduino.h>
#include <Servo.h>
#include <EEPROM.h>
#include <avr/interrupt.h>
#include <util/atomic.h>
#include <stdlib.h>
#include <string.h>

constexpr uint32_t UART_BAUD = 9600;
constexpr uint8_t LEFT_IN1 = 8;   // PB0
constexpr uint8_t LEFT_IN2 = 9;   // PB1
constexpr uint8_t RIGHT_IN1 = 5;  // PD5
constexpr uint8_t RIGHT_IN2 = 6;  // PD6
constexpr uint8_t LEFT_SERVO_PIN = A4;
constexpr uint8_t RIGHT_SERVO_PIN = 7;
constexpr uint8_t RAMP_STEP = 5;
constexpr uint16_t RAMP_PERIOD_MS = 5;

struct __attribute__((packed)) RobotSettings {
  uint32_t magic;
  uint8_t version;
  uint8_t speed;
  int16_t trim;
  uint8_t leftMin;
  uint8_t leftMax;
  uint8_t rightMin;
  uint8_t rightMax;
  uint8_t checksum;
};
constexpr uint32_t SETTINGS_MAGIC = 0x52583343UL; // RX3C
constexpr uint8_t SETTINGS_VERSION = 1;
RobotSettings settings;

uint8_t settingsCrc(const RobotSettings &s) {
  const uint8_t *bytes = (const uint8_t *)&s;
  uint8_t crc = 0;
  for (uint8_t i = 0; i < sizeof(RobotSettings)-1; i++) {
    crc ^= bytes[i];
    for (uint8_t j = 0; j < 8; j++) crc = (crc & 0x80) ? (uint8_t)((crc<<1)^0x07) : (uint8_t)(crc<<1);
  }
  return crc;
}

bool settingsValid(const RobotSettings &s) {
  return s.magic == SETTINGS_MAGIC && s.version == SETTINGS_VERSION &&
         s.trim >= -100 && s.trim <= 100 &&
         s.leftMin <= 180 && s.leftMax <= 180 && s.leftMin + 5 <= s.leftMax &&
         s.rightMin <= 180 && s.rightMax <= 180 && s.rightMin + 5 <= s.rightMax &&
         s.checksum == settingsCrc(s);
}

void defaults() {
  memset(&settings, 0, sizeof(settings));
  settings.magic = SETTINGS_MAGIC;
  settings.version = SETTINGS_VERSION;
  settings.speed = 160;
  settings.trim = 0;
  settings.leftMin = 0;
  settings.leftMax = 180;
  settings.rightMin = 0;
  settings.rightMax = 180;
  settings.checksum = settingsCrc(settings);
}

void loadSettings() {
  EEPROM.get(0, settings);
  if (!settingsValid(settings)) defaults();
}

bool saveSettings() {
  settings.checksum = settingsCrc(settings);
  EEPROM.put(0, settings); // update() is used internally, no wear when unchanged
  RobotSettings check;
  EEPROM.get(0, check);
  return settingsValid(check) && memcmp(&settings, &check, sizeof(settings)) == 0;
}

void printSettings() {
  Serial.print(F("CFG,"));
  Serial.print(settings.speed); Serial.print(',');
  Serial.print(settings.trim); Serial.print(',');
  Serial.print(settings.leftMin); Serial.print(',');
  Serial.print(settings.leftMax); Serial.print(',');
  Serial.print(settings.rightMin); Serial.print(',');
  Serial.println(settings.rightMax);
}

// 2 x 8-bit PWM channels, both turn off to 0/0, including direction reversals.
volatile uint8_t pwmLeftDuty=0, pwmRightDuty=0;
volatile int8_t pwmLeftDir=0, pwmRightDir=0;

ISR(TIMER2_OVF_vect) {
  PORTB &= (uint8_t)~(_BV(PB0)|_BV(PB1)); // LEFT coast
  PORTD &= (uint8_t)~(_BV(PD5)|_BV(PD6)); // RIGHT coast
  TIMSK2 = _BV(TOIE2);
  const uint8_t ld = pwmLeftDuty, rd = pwmRightDuty;
  const int8_t ldir=pwmLeftDir, rdir=pwmRightDir;
  if (ld && ldir) {
    if (ldir > 0) PORTB |= _BV(PB1); else PORTB |= _BV(PB0);
    if (ld != 255) { OCR2A=ld; TIMSK2 |= _BV(OCIE2A); }
  }
  if (rd && rdir) {
    if (rdir > 0) PORTD |= _BV(PD6); else PORTD |= _BV(PD5);
    if (rd != 255) { OCR2B=rd; TIMSK2 |= _BV(OCIE2B); }
  }
}
ISR(TIMER2_COMPA_vect) { PORTB &= (uint8_t)~(_BV(PB0)|_BV(PB1)); }
ISR(TIMER2_COMPB_vect) { PORTD &= (uint8_t)~(_BV(PD5)|_BV(PD6)); }

void initMotorPwm() {
  pinMode(LEFT_IN1, OUTPUT); pinMode(LEFT_IN2, OUTPUT);
  pinMode(RIGHT_IN1, OUTPUT); pinMode(RIGHT_IN2, OUTPUT);
  digitalWrite(LEFT_IN1,LOW); digitalWrite(LEFT_IN2,LOW);
  digitalWrite(RIGHT_IN1,LOW); digitalWrite(RIGHT_IN2,LOW);
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    TCCR2A=0; TCCR2B=0; TCNT2=0; OCR2A=255; OCR2B=255;
    TIFR2 = _BV(TOV2)|_BV(OCF2A)|_BV(OCF2B);
    TIMSK2 = _BV(TOIE2);
    TCCR2B = _BV(CS22); // 16MHz /64 /256 = 976.56 Hz
  }
}

void applyMotorDuty(int16_t left, int16_t right) {
  int8_t ldir = (left>0) - (left<0);
  int8_t rdir = (right>0) - (right<0);
  uint8_t ld=(uint8_t)abs(left), rd=(uint8_t)abs(right);
  if (ld<10) { ld=0; ldir=0; }
  if (rd<10) { rd=0; rdir=0; }
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    PORTB &= (uint8_t)~(_BV(PB0)|_BV(PB1));
    PORTD &= (uint8_t)~(_BV(PD5)|_BV(PD6));
    pwmLeftDir=ldir; pwmRightDir=rdir;
    pwmLeftDuty=ld; pwmRightDuty=rd;
  }
}

enum Motion : uint8_t { STOPPED, FORWARD, BACKWARD, LEFT, RIGHT };
Motion motion = STOPPED;
int16_t currentLeft=0, currentRight=0;
uint32_t lastRamp=0;

int16_t approachSpeed(int16_t current, int16_t target) {
  if (current>0 && target<0) target=0;
  if (current<0 && target>0) target=0;
  if (current<target) return min((int16_t)(current+RAMP_STEP), target);
  if (current>target) return max((int16_t)(current-RAMP_STEP), target);
  return current;
}

void stopMotors() {
  motion=STOPPED; currentLeft=currentRight=0;
  applyMotorDuty(0,0);
}

void updateMotors() {
  if (motion == STOPPED) return;
  const uint32_t now=millis();
  if ((uint32_t)(now-lastRamp) < RAMP_PERIOD_MS) return;
  lastRamp=now;
  int16_t lt=0, rt=0;
  const int16_t speed=settings.speed;
  const int16_t correctedRight=constrain((int16_t)(speed+settings.trim), (int16_t)0, (int16_t)255);
  switch (motion) {
    case FORWARD:  lt=speed;  rt=correctedRight;  break;
    case BACKWARD: lt=-speed; rt=-correctedRight; break;
    case LEFT:     lt=-speed; rt=speed;           break;
    case RIGHT:    lt=speed;  rt=-speed;          break;
    default: break;
  }
  currentLeft=approachSpeed(currentLeft,lt);
  currentRight=approachSpeed(currentRight,rt);
  applyMotorDuty(currentLeft,currentRight);
}

Servo leftServo, rightServo;
int leftServoAngle=90, rightServoAngle=90;
constexpr int SERVO_STEP=1;
constexpr uint16_t SERVO_INTERVAL_MS=5, SERVO_DETACH_DELAY_MS=200;
uint32_t lastServoTime=0, leftServoLastActiveTime=0, rightServoLastActiveTime=0;
bool leftServoAttached=false, rightServoAttached=false;
bool leftServoUp=false, leftServoDown=false, rightServoUp=false, rightServoDown=false;

int angleToPulse(int angle) { return map(constrain(angle,0,180),0,180,750,2250); }
void writeServoAngle(Servo &s, int angle) { s.writeMicroseconds(angleToPulse(angle)); }
void attachLeftServoIfNeeded() {
  if (!leftServoAttached) {
    leftServo.attach(LEFT_SERVO_PIN);
    leftServoAttached=true;
    writeServoAngle(leftServo,leftServoAngle);
  }
  leftServoLastActiveTime=millis();
}
void attachRightServoIfNeeded() {
  if (!rightServoAttached) {
    rightServo.attach(RIGHT_SERVO_PIN);
    rightServoAttached=true;
    writeServoAngle(rightServo,rightServoAngle);
  }
  rightServoLastActiveTime=millis();
}
void detachServosIfNeeded() {
  const uint32_t now=millis();
  if (leftServoAttached && !(leftServoUp||leftServoDown) && now-leftServoLastActiveTime>=SERVO_DETACH_DELAY_MS) {
    leftServo.detach(); leftServoAttached=false;
  }
  if (rightServoAttached && !(rightServoUp||rightServoDown) && now-rightServoLastActiveTime>=SERVO_DETACH_DELAY_MS) {
    rightServo.detach(); rightServoAttached=false;
  }
}
void updateServos() {
  const uint32_t now=millis();
  if (now-lastServoTime<SERVO_INTERVAL_MS) { detachServosIfNeeded(); return; }
  lastServoTime=now;
  if (leftServoUp||leftServoDown) {
    attachLeftServoIfNeeded();
    leftServoAngle=constrain(leftServoAngle+(leftServoDown?SERVO_STEP:-SERVO_STEP), (int)settings.leftMin, (int)settings.leftMax);
    writeServoAngle(leftServo,leftServoAngle);
    leftServoLastActiveTime=now;
  }
  if (rightServoUp||rightServoDown) {
    attachRightServoIfNeeded();
    rightServoAngle=constrain(rightServoAngle+(rightServoDown?SERVO_STEP:-SERVO_STEP), (int)settings.rightMin, (int)settings.rightMax);
    writeServoAngle(rightServo,rightServoAngle);
    rightServoLastActiveTime=now;
  }
  detachServosIfNeeded();
}

bool parseIntStrict(const char *s, long &out) {
  if (!s || !*s) return false;
  char *end;
  const long value=strtol(s,&end,10);
  if (*end!='\0') return false;
  out=value;
  return true;
}

void handleSimpleCommand(char cmd) {
  switch(cmd) {
    case 'F': motion=FORWARD; break;
    case 'B': motion=BACKWARD; break;
    case 'L': motion=LEFT; break;
    case 'R': motion=RIGHT; break;
    case 'S': stopMotors(); break;
    case 'Q': attachLeftServoIfNeeded(); leftServoUp=true; leftServoDown=false; break;
    case 'q': leftServoUp=false; leftServoLastActiveTime=millis(); break;
    case 'A': attachLeftServoIfNeeded(); leftServoDown=true; leftServoUp=false; break;
    case 'a': leftServoDown=false; leftServoLastActiveTime=millis(); break;
    case 'W': attachRightServoIfNeeded(); rightServoDown=true; rightServoUp=false; break;
    case 'w': rightServoDown=false; rightServoLastActiveTime=millis(); break;
    case 'D': attachRightServoIfNeeded(); rightServoUp=true; rightServoDown=false; break;
    case 'd': rightServoUp=false; rightServoLastActiveTime=millis(); break;
    case '?': Serial.print(F("SPEED=")); Serial.println(settings.speed); break;
  }
}

bool isSimple(char c) {
  switch(c) {
    case 'F':case 'B':case 'L':case 'R':case 'S':case '?':
    case 'Q':case 'q':case 'A':case 'a':case 'W':case 'w':case 'D':case 'd': return true;
    default: return false;
  }
}

void handleLine(char *line) {
  if (!line[0]) return;
  if (!line[1] && isSimple(line[0])) {handleSimpleCommand(line[0]); return;}
  if (strcmp(line,"CFG?")==0) {printSettings(); return;}
  if (strcmp(line,"COMMIT")==0) {
    Serial.println(saveSettings()?F("SAVED"):F("ERR EEPROM")); return;
  }
  if (line[0]=='V' || line[0]=='v') {
    if (strcmp(line+1,"?")==0) {handleSimpleCommand('?');return;}
    long val;
    if (!parseIntStrict(line+1,val) || val<0 || val>255) {
      Serial.println(F("ERR SPEED 0..255")); return;
    }
    settings.speed=(uint8_t)val;
    Serial.print(F("SPEED=")); Serial.println(settings.speed);
    return;
  }
  if (strncmp(line,"CFG,",4)==0) {
    // Strict parsing, exactly six integer fields, no partial updates on failure.
    long fields[6];
    char *p=line+4;
    for (uint8_t i=0;i<6;i++) {
      char *end;
      fields[i]=strtol(p,&end,10);
      if (end==p || (i<5 ? *end!=',' : *end!='\0')) {
        Serial.println(F("ERR CFG FORMAT")); return;
      }
      p=end+1;
    }
    if (fields[0]<0 || fields[0]>255 || fields[1]<-100 || fields[1]>100 ||
        fields[2]<0 || fields[2]>180 || fields[3]<0 || fields[3]>180 || fields[2]+5>fields[3] ||
        fields[4]<0 || fields[4]>180 || fields[5]<0 || fields[5]>180 || fields[4]+5>fields[5]) {
      Serial.println(F("ERR CFG RANGE")); return;
    }
    settings.speed=(uint8_t)fields[0]; settings.trim=(int16_t)fields[1];
    settings.leftMin=(uint8_t)fields[2]; settings.leftMax=(uint8_t)fields[3];
    settings.rightMin=(uint8_t)fields[4]; settings.rightMax=(uint8_t)fields[5];
    leftServoAngle=constrain(leftServoAngle,(int)settings.leftMin,(int)settings.leftMax);
    rightServoAngle=constrain(rightServoAngle,(int)settings.rightMin,(int)settings.rightMax);
    printSettings();
    return;
  }
  Serial.println(F("ERR CMD"));
}

char uartLine[72];
uint8_t uartLength=0;
void readUartCommands() {
  while(Serial.available()) {
    char c=(char)Serial.read();
    if (c=='\r'||c=='\n') {
      uartLine[uartLength]='\0'; handleLine(uartLine); uartLength=0;
      continue;
    }
    if (!uartLength && isSimple(c)) { handleSimpleCommand(c); continue; }
    if (uartLength<sizeof(uartLine)-1) uartLine[uartLength++]=c;
    else uartLength=0;
  }
}

void setup() {
  Serial.begin(UART_BAUD);
  loadSettings();
  initMotorPwm();
  stopMotors();
  lastRamp=millis();
}
void loop() {
  readUartCommands();
  updateMotors();
  updateServos();
}
