@echo off
cd /d "%~dp0"
py robotx_uart_control.py
pause
