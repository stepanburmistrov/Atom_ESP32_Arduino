#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RobotX UART Control Panel
=========================

Красивый пульт для отладки робота напрямую с компьютера до подключения ESP32.

Что делает:
- открывает COM-порт Arduino Nano;
- отправляет те же UART-команды, что и ESP32 Wi-Fi модуль;
- позволяет управлять мышью по большим экранным кнопкам;
- позволяет управлять клавиатурой.

Протокол:
F/B/L/R/S — движение;
Q/q/A/a — левая серва;
W/w/D/d — правая серва.
Каждая команда отправляется как ASCII-символ + '\n'.
"""

from __future__ import annotations

import sys
import time
import tkinter as tk
from tkinter import ttk, messagebox
from dataclasses import dataclass
from typing import Dict, Optional, Set

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None


BAUD_DEFAULT = 9600
APP_VERSION = "3.0"

# Коды команд должны совпадать с Arduino Nano и ESP32 Web UI.
KEY_PRESS_COMMANDS = {
    "up": "F",
    "down": "B",
    "left": "L",
    "right": "R",
    "space": "S",
    "q": "Q",
    "a": "A",
    "w": "W",
    "d": "D",
}

KEY_RELEASE_COMMANDS = {
    "up": "S",
    "down": "S",
    "left": "S",
    "right": "S",
    "space": "S",
    "q": "q",
    "a": "a",
    "w": "w",
    "d": "d",
}


@dataclass(frozen=True)
class HoldButtonSpec:
    code: str
    title: str
    subtitle: str
    press_cmd: str
    release_cmd: str
    row: int
    col: int
    kind: str
    width: int = 178
    height: int = 104


class HoldButton(tk.Frame):
    """Большая кнопка с аккуратной вёрсткой текста.

    Обычный ttk.Button на Windows часто обрезает многострочный русский текст.
    Поэтому здесь используется Frame + Label с фиксированной высотой и шириной:
    текст не обрезается, а вся кнопка работает как удерживаемая.
    """

    COLORS = {
        "servo": {"bg": "#f39c12", "active": "#d88a0f", "shadow": "#8a5600", "fg": "#ffffff"},
        "drive": {"bg": "#2d8cff", "active": "#2472d0", "shadow": "#154f97", "fg": "#ffffff"},
        "stop": {"bg": "#e74c3c", "active": "#c0392b", "shadow": "#7f1d17", "fg": "#ffffff"},
    }

    def __init__(self, master: tk.Misc, app: "RobotXControlApp", spec: HoldButtonSpec) -> None:
        self.spec = spec
        self.app = app
        self.palette = self.COLORS[spec.kind]
        super().__init__(master, width=spec.width, height=spec.height + 7, bg=self.palette["shadow"])
        self.grid_propagate(False)
        self.pack_propagate(False)

        self.face = tk.Frame(self, bg=self.palette["bg"], width=spec.width, height=spec.height)
        self.face.place(x=0, y=0, width=spec.width, height=spec.height)
        self.face.pack_propagate(False)

        # Для STOP не нужен отдельный крупный код сверху.
        if spec.code == "STOP":
            code_text = "STOP"
            title_text = spec.title
            code_font = ("Segoe UI", 20, "bold")
            title_font = ("Segoe UI", 10, "bold")
        else:
            code_text = spec.code
            title_text = spec.title
            code_font = ("Segoe UI", 21, "bold")
            title_font = ("Segoe UI", 11, "bold")

        self.code_label = tk.Label(
            self.face,
            text=code_text,
            bg=self.palette["bg"],
            fg=self.palette["fg"],
            font=code_font,
        )
        self.code_label.place(relx=0.5, rely=0.23, anchor="center")

        self.title_label = tk.Label(
            self.face,
            text=title_text,
            bg=self.palette["bg"],
            fg=self.palette["fg"],
            font=title_font,
            justify="center",
            wraplength=spec.width - 14,
        )
        self.title_label.place(relx=0.5, rely=0.56, anchor="center")

        self.subtitle_label = tk.Label(
            self.face,
            text=spec.subtitle,
            bg=self.palette["bg"],
            fg="#fff7df" if spec.kind == "servo" else "#dcecff",
            font=("Segoe UI", 8, "bold"),
            justify="center",
            wraplength=spec.width - 14,
        )
        self.subtitle_label.place(relx=0.5, rely=0.82, anchor="center")

        self._bind_all_children("<ButtonPress-1>", self._on_press)
        self._bind_all_children("<ButtonRelease-1>", self._on_release)
        self._bind_all_children("<Leave>", self._on_leave)

    def _bind_all_children(self, sequence: str, callback) -> None:
        widgets = [self, self.face, self.code_label, self.title_label, self.subtitle_label]
        for widget in widgets:
            widget.bind(sequence, callback)

    def _on_press(self, event: tk.Event) -> None:
        self.face.configure(bg=self.palette["active"])
        for widget in (self.code_label, self.title_label, self.subtitle_label):
            widget.configure(bg=self.palette["active"])
        self.face.place_configure(y=5)
        self.app.send_command(self.spec.press_cmd)

    def _on_release(self, event: tk.Event) -> None:
        self._release_visual()
        self.app.send_command(self.spec.release_cmd)

    def _on_leave(self, event: tk.Event) -> None:
        # Если кнопку удерживали мышью и увели курсор — лучше остановить действие.
        if event.state & 0x0100:
            self._release_visual()
            self.app.send_command(self.spec.release_cmd)

    def _release_visual(self) -> None:
        self.face.configure(bg=self.palette["bg"])
        for widget in (self.code_label, self.title_label, self.subtitle_label):
            widget.configure(bg=self.palette["bg"])
        self.face.place_configure(y=0)


class RobotXControlApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("RobotX UART Control")
        self.geometry("1080x680")
        self.minsize(1000, 640)
        self.configure(bg="#0f1016")

        self.serial_port: Optional["serial.Serial"] = None
        self.last_cmd = "S"
        self.pressed_keys: Set[str] = set()
        self.available_ports: Dict[str, str] = {}
        self.settings_window: Optional[tk.Toplevel] = None
        self.cfg_vars = {}
        self._rx_buffer = ""
        self._awaiting_save = False
        self._awaiting_cfg = False

        self._build_styles()
        self._build_ui()
        self._bind_keyboard()
        self.refresh_ports()

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(50, self.poll_serial)

    # ---------- UI ----------

    def _build_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("Dark.TFrame", background="#0f1016")
        style.configure("Panel.TFrame", background="#181923")
        style.configure("Card.TFrame", background="#12131a")
        style.configure("TLabel", background="#0f1016", foreground="#f5f5f5", font=("Segoe UI", 11))
        style.configure("Title.TLabel", background="#0f1016", foreground="#ffffff", font=("Segoe UI", 22, "bold"))
        style.configure("PanelTitle.TLabel", background="#181923", foreground="#ffffff", font=("Segoe UI", 20, "bold"))
        style.configure("Hint.TLabel", background="#0f1016", foreground="#b7bcc8", font=("Segoe UI", 10))
        style.configure("Status.TLabel", background="#0f1016", foreground="#f39c12", font=("Segoe UI", 18, "bold"))
        style.configure("Small.TButton", font=("Segoe UI", 10), padding=(10, 6))
        style.configure("Connect.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 6))

    def _build_ui(self) -> None:
        root = ttk.Frame(self, style="Dark.TFrame", padding=18)
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root, style="Dark.TFrame")
        header.pack(fill="x", pady=(0, 14))

        title_block = ttk.Frame(header, style="Dark.TFrame")
        title_block.pack(side="left", fill="x", expand=True)
        ttk.Label(title_block, text="RobotX UART Control", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            title_block,
            text="Отладочный пульт: компьютер → USB-UART → Arduino Nano → робот",
            style="Hint.TLabel",
        ).pack(anchor="w", pady=(2, 0))

        tk.Button(
            header, text="⚙", command=self.open_settings,
            bg="#292e3c", fg="white", activebackground="#3d4559",
            font=("Segoe UI Symbol", 22), relief="flat", bd=0,
            width=3, cursor="hand2"
        ).pack(side="right", padx=(12, 0))

        self.status_label = ttk.Label(header, text="Команда: S", style="Status.TLabel")
        self.status_label.pack(side="right", padx=(16, 0))

        connection = ttk.Frame(root, style="Panel.TFrame", padding=14)
        connection.pack(fill="x", pady=(0, 14))

        for col in range(8):
            connection.grid_columnconfigure(col, weight=0)
        connection.grid_columnconfigure(1, weight=1)
        connection.grid_columnconfigure(7, weight=1)

        tk.Label(connection, text="COM-порт", bg="#181923", fg="#ffffff", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, sticky="w", padx=(0, 8)
        )
        self.port_combo = ttk.Combobox(connection, width=42, state="readonly")
        self.port_combo.grid(row=0, column=1, sticky="ew", padx=(0, 8))

        ttk.Button(connection, text="Обновить", style="Small.TButton", command=self.refresh_ports).grid(row=0, column=2, padx=(0, 14))

        tk.Label(connection, text="Скорость", bg="#181923", fg="#ffffff", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=3, sticky="w", padx=(0, 8)
        )
        self.baud_var = tk.StringVar(value=str(BAUD_DEFAULT))
        ttk.Entry(connection, textvariable=self.baud_var, width=9).grid(row=0, column=4, sticky="w", padx=(0, 14))

        self.connect_btn = ttk.Button(connection, text="Подключиться", style="Connect.TButton", command=self.toggle_connection)
        self.connect_btn.grid(row=0, column=5, sticky="w", padx=(0, 12))

        self.connection_badge = tk.Label(
            connection,
            text="● Не подключено",
            bg="#20212c",
            fg="#ff7675",
            font=("Segoe UI", 10, "bold"),
            padx=12,
            pady=7,
        )
        self.connection_badge.grid(row=0, column=6, sticky="w")

        main = ttk.Frame(root, style="Dark.TFrame")
        main.pack(fill="both", expand=True)
        main.grid_columnconfigure(0, weight=1, uniform="main")
        main.grid_columnconfigure(1, weight=1, uniform="main")
        main.grid_rowconfigure(0, weight=1)

        servo_panel = ttk.Frame(main, style="Panel.TFrame", padding=20)
        servo_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 9))
        drive_panel = ttk.Frame(main, style="Panel.TFrame", padding=20)
        drive_panel.grid(row=0, column=1, sticky="nsew", padx=(9, 0))

        self._build_servo_panel(servo_panel)
        self._build_drive_panel(drive_panel)

        bottom = ttk.Frame(root, style="Dark.TFrame", padding=(0, 12, 0, 0))
        bottom.pack(fill="x")

        ttk.Label(
            bottom,
            text="Клавиатура: стрелки — движение • Space — стоп • Q/A — левая серва • W/D — правая серва. "
                 "Кнопки серв удерживаются, отпускание отправляет стоп-команду.",
            style="Hint.TLabel",
        ).pack(anchor="w", pady=(0, 8))

        log_wrap = tk.Frame(bottom, bg="#2c2f3a", padx=1, pady=1)
        log_wrap.pack(fill="x")
        self.log_text = tk.Text(
            log_wrap,
            height=4,
            bg="#090a0f",
            fg="#e8e8e8",
            insertbackground="#ffffff",
            relief="flat",
            font=("Consolas", 10),
            padx=10,
            pady=8,
        )
        self.log_text.pack(fill="x")

        self.log("Готово. Подключите Nano (9600 бод) или ESP32-C3 через USB (115200 бод).")
        if serial is None:
            self.log("pyserial не установлен. Установите: pip install pyserial")

    def _build_servo_panel(self, panel: ttk.Frame) -> None:
        ttk.Label(panel, text="Сервоприводы", style="PanelTitle.TLabel").pack(anchor="center", pady=(0, 4))
        tk.Label(
            panel,
            text="Q/A — левая серва, W/D — правая серва",
            bg="#181923",
            fg="#b7bcc8",
            font=("Segoe UI", 10),
        ).pack(anchor="center", pady=(0, 18))

        grid = tk.Frame(panel, bg="#181923")
        grid.pack(expand=True)

        specs = [
            HoldButtonSpec("Q", "Левая серва вверх", "удерживать", "Q", "q", 0, 0, "servo", 190, 108),
            HoldButtonSpec("W", "Правая серва вверх", "удерживать", "W", "w", 0, 1, "servo", 190, 108),
            HoldButtonSpec("A", "Левая серва вниз", "удерживать", "A", "a", 1, 0, "servo", 190, 108),
            HoldButtonSpec("D", "Правая серва вниз", "удерживать", "D", "d", 1, 1, "servo", 190, 108),
        ]
        for spec in specs:
            btn = HoldButton(grid, self, spec)
            btn.grid(row=spec.row, column=spec.col, padx=14, pady=12)

    def _build_drive_panel(self, panel: ttk.Frame) -> None:
        ttk.Label(panel, text="Движение", style="PanelTitle.TLabel").pack(anchor="center", pady=(0, 4))
        tk.Label(
            panel,
            text="Стрелки на клавиатуре или кнопки мышью",
            bg="#181923",
            fg="#b7bcc8",
            font=("Segoe UI", 10),
        ).pack(anchor="center", pady=(0, 18))

        grid = tk.Frame(panel, bg="#181923")
        grid.pack(expand=True)

        specs = [
            HoldButtonSpec("▲", "Вперёд", "F", "F", "S", 0, 1, "drive", 150, 94),
            HoldButtonSpec("◀", "Влево", "L", "L", "S", 1, 0, "drive", 150, 94),
            HoldButtonSpec("STOP", "Остановить", "Space / S", "S", "S", 1, 1, "stop", 150, 94),
            HoldButtonSpec("▶", "Вправо", "R", "R", "S", 1, 2, "drive", 150, 94),
            HoldButtonSpec("▼", "Назад", "B", "B", "S", 2, 1, "drive", 150, 94),
        ]
        for spec in specs:
            btn = HoldButton(grid, self, spec)
            btn.grid(row=spec.row, column=spec.col, padx=9, pady=8)

    # ---------- Robot EEPROM settings ----------

    CFG_FIELDS = (
        ("speed", "Скорость (0–255)", 0, 255),
        ("trim", "Коррекция справа (−100…+100)", -100, 100),
        ("leftMin", "Левая серва · минимум (°)", 0, 175),
        ("leftMax", "Левая серва · максимум (°)", 5, 180),
        ("rightMin", "Правая серва · минимум (°)", 0, 175),
        ("rightMax", "Правая серва · максимум (°)", 5, 180),
    )

    def open_settings(self) -> None:
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.lift()
            return
        self.send_command("S")
        win = tk.Toplevel(self)
        self.settings_window = win
        win.title("Настройки RobotX — EEPROM Nano")
        win.geometry("560x565")
        win.minsize(520, 530)
        win.configure(bg="#181923")
        win.transient(self)
        win.protocol("WM_DELETE_WINDOW", self.close_settings)

        tk.Label(win, text="⚙ Настройки робота", bg="#181923", fg="white",
                 font=("Segoe UI", 20, "bold")).pack(anchor="w", padx=23, pady=(20, 6))
        tk.Label(win, text="Параметры сохраняются в EEPROM Arduino Nano.\n"
                 "Коррекция + ускоряет правый мотор, − замедляет (только F/B).",
                 bg="#181923", fg="#b7bcc8", justify="left",
                 font=("Segoe UI", 10)).pack(anchor="w", padx=23, pady=(0, 14))

        form = tk.Frame(win, bg="#181923")
        form.pack(fill="x", padx=23)
        self.cfg_vars = {}
        default_values = [160, 0, 0, 180, 0, 180]
        for idx, (key, title, mini, maxi) in enumerate(self.CFG_FIELDS):
            row = idx // 2
            col = idx % 2
            cell = tk.Frame(form, bg="#181923")
            cell.grid(row=row, column=col, sticky="ew", padx=(0, 15), pady=8)
            tk.Label(cell, text=title, bg="#181923", fg="#cbd1dc",
                     font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 4))
            var = tk.StringVar(value=str(default_values[idx]))
            self.cfg_vars[key] = var
            tk.Entry(cell, textvariable=var, bg="#0f1016", fg="white",
                     insertbackground="white", relief="flat",
                     highlightthickness=1, highlightbackground="#596174",
                     font=("Consolas", 16), width=13).pack(fill="x", ipady=6)
        form.grid_columnconfigure(0, weight=1)
        form.grid_columnconfigure(1, weight=1)

        self.settings_status = tk.Label(win, bg="#181923", fg="#aec0dc",
                                        wraplength=500, justify="left",
                                        font=("Segoe UI", 10), text="")
        self.settings_status.pack(anchor="w", fill="x", padx=23, pady=(20, 4))
        buttons = tk.Frame(win, bg="#181923")
        buttons.pack(fill="x", padx=23, pady=10)
        btnstyle = dict(fg="white", relief="flat", font=("Segoe UI", 10, "bold"),
                        padx=14, pady=10, cursor="hand2")
        tk.Button(buttons, text="Обновить с Nano", command=self.request_cfg,
                  bg="#33394b", **btnstyle).pack(side="left", padx=(0, 8))
        tk.Button(buttons, text="Применить", command=self.apply_cfg,
                  bg="#3a526e", **btnstyle).pack(side="left", padx=(0, 8))
        tk.Button(buttons, text="Сохранить EEPROM", command=self.save_cfg,
                  bg="#246dd1", **btnstyle).pack(side="left")
        tk.Label(win, text="Подключение: Nano USB → 9600 бод; ESP USB → 115200 бод.\n"
                 "Для чтения через ESP нужен обратный UART Nano TX → ESP GPIO5\n"
                 "через преобразователь уровней 5 В → 3,3 В.",
                 bg="#181923", fg="#9198a9", justify="left",
                 font=("Segoe UI", 9)).pack(anchor="w", padx=23, pady=(18, 0))
        self.cfg_status("Показаны начальные значения. Чтение из Nano уточнит их при наличии обратной связи.")
        self.request_cfg()

    def close_settings(self) -> None:
        self.send_command("S")
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.destroy()
        self.settings_window = None

    def cfg_status(self, message: str, error: bool = False) -> None:
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_status.configure(text=message, fg="#ff8f88" if error else "#aec0dc")

    def request_cfg(self) -> None:
        if not self.serial_port or not self.serial_port.is_open:
            self.cfg_status("Подключите COM-порт, чтобы считать EEPROM.", True)
            return
        self.cfg_status("Запрашиваю параметры из Nano…")
        self._awaiting_cfg = True
        self.send_command("CFG?")
        self.after(1200, self.check_cfg_timeout)

    def check_cfg_timeout(self) -> None:
        if self._awaiting_cfg:
            self._awaiting_cfg = False
            self.cfg_status("Нет ответа Nano. Отображены исходные или ранее введённые значения; они не подтверждены EEPROM.", True)

    def validated_cfg(self) -> str:
        values = []
        for key, title, mini, maxi in self.CFG_FIELDS:
            raw = self.cfg_vars[key].get().strip()
            try:
                val = int(raw)
            except ValueError:
                raise ValueError(f"Поле «{title}» должно быть целым числом.")
            if not mini <= val <= maxi:
                raise ValueError(f"Поле «{title}»: диапазон {mini}…{maxi}.")
            values.append(val)
        if values[2] + 5 > values[3] or values[4] + 5 > values[5]:
            raise ValueError("Между минимальным и максимальным углом должен быть зазор минимум 5°.")
        return "CFG," + ",".join(map(str, values))

    def apply_cfg(self) -> bool:
        try:
            cmd = self.validated_cfg()
        except ValueError as exc:
            self.cfg_status(str(exc), True)
            return False
        if not self.serial_port or not self.serial_port.is_open:
            self.cfg_status("Не выбран активный COM-порт.", True)
            return False
        self.send_command(cmd)
        self.cfg_status("Настройки отправлены в оперативную память Nano (без записи EEPROM).")
        return True

    def save_cfg(self) -> None:
        if not self.apply_cfg():
            return
        self._awaiting_save = True
        self.send_command("COMMIT")
        self.cfg_status("Ожидаю подтверждения сохранения EEPROM…")
        self.after(1300, self.check_save_timeout)

    def check_save_timeout(self) -> None:
        if self._awaiting_save:
            self._awaiting_save = False
            self.cfg_status("Команды отправлены. Нет подтверждения Nano; без обратного UART запись EEPROM не проверена.", True)

    def handle_robot_reply(self, line: str) -> None:
        if "[NANO] " in line:
            line = line.split("[NANO] ", 1)[1]
        if line.startswith("CFG,"):
            self._awaiting_cfg = False
            try:
                raw = line[4:].split(",")
                if len(raw) != 6: return
                vals = [int(x) for x in raw]
            except ValueError:
                return
            for (key, _title, _mini, _maxi), val in zip(self.CFG_FIELDS, vals):
                if key in self.cfg_vars:
                    self.cfg_vars[key].set(str(val))
            self.cfg_status("Параметры получены от Arduino Nano.")
        elif line == "SAVED":
            self._awaiting_save = False
            self.cfg_status("Сохранено в EEPROM Arduino Nano.")
        elif line.startswith("ERR"):
            self._awaiting_cfg = False
            self._awaiting_save = False
            self.cfg_status("Ошибка Nano: " + line, True)

    def poll_serial(self) -> None:
        try:
            if self.serial_port and self.serial_port.is_open and self.serial_port.in_waiting:
                chunk = self.serial_port.read(self.serial_port.in_waiting).decode("utf-8", errors="replace")
                self._rx_buffer += chunk
                while "\n" in self._rx_buffer:
                    line, self._rx_buffer = self._rx_buffer.split("\n", 1)
                    line = line.strip()
                    if line:
                        self.log("RX: " + line)
                        self.handle_robot_reply(line)
                if len(self._rx_buffer) > 1024:
                    self._rx_buffer = ""
        except Exception as exc:
            self.log("Ошибка чтения UART: " + str(exc))
        self.after(50, self.poll_serial)

    # ---------- serial ----------

    def refresh_ports(self) -> None:
        self.available_ports.clear()
        values = []

        if list_ports is not None:
            for port in list_ports.comports():
                label = f"{port.device} — {port.description}"
                self.available_ports[label] = port.device
                values.append(label)

        self.port_combo["values"] = values
        if values and not self.port_combo.get():
            self.port_combo.current(0)
        if not values:
            self.log("COM-порты не найдены. Подключите Arduino Nano или проверьте драйвер CH340/FTDI.")

    def toggle_connection(self) -> None:
        if self.serial_port and self.serial_port.is_open:
            self.disconnect()
        else:
            self.connect()

    def connect(self) -> None:
        if serial is None:
            messagebox.showerror("pyserial не установлен", "Выполните: pip install pyserial")
            return

        selected = self.port_combo.get()
        port = self.available_ports.get(selected)
        if not port:
            messagebox.showwarning("COM-порт", "Выберите COM-порт Arduino Nano.")
            return

        try:
            baud = int(self.baud_var.get().strip())
        except ValueError:
            messagebox.showwarning("Скорость", "Скорость должна быть числом, например 9600.")
            return

        try:
            self.serial_port = serial.Serial(port=port, baudrate=baud, timeout=0, write_timeout=0.5)
            time.sleep(1.8)  # Arduino Nano может перезагрузиться при открытии порта
            self.connect_btn.config(text="Отключиться")
            self.connection_badge.config(text=f"● Подключено: {port} @ {baud}", fg="#55efc4")
            self.log(f"Подключено к {port} на {baud} бод.")
            self.send_command("S")
        except Exception as exc:
            self.serial_port = None
            messagebox.showerror("Ошибка подключения", str(exc))
            self.log(f"Ошибка подключения: {exc}")

    def disconnect(self) -> None:
        try:
            if self.serial_port and self.serial_port.is_open:
                self.send_command("S")
                self.serial_port.close()
        finally:
            self.serial_port = None
            self.connect_btn.config(text="Подключиться")
            self.connection_badge.config(text="● Не подключено", fg="#ff7675")
            self.log("Отключено.")

    def send_command(self, cmd: str) -> None:
        cmd = cmd.strip()
        if not cmd:
            return

        self.last_cmd = cmd
        self.status_label.config(text=f"Команда: {cmd}")

        line = (cmd + "\n").encode("ascii")
        if self.serial_port and self.serial_port.is_open:
            try:
                self.serial_port.write(line)
                self.serial_port.flush()
                self.log(f"TX: {cmd}")
            except Exception as exc:
                self.log(f"Ошибка отправки {cmd}: {exc}")
                messagebox.showerror("UART", str(exc))
        else:
            self.log(f"DEMO TX: {cmd}  (порт не подключен)")

    # ---------- keyboard ----------

    def _bind_keyboard(self) -> None:
        self.bind("<KeyPress>", self.on_key_press)
        self.bind("<KeyRelease>", self.on_key_release)

    def on_key_press(self, event: tk.Event) -> None:
        key = event.keysym.lower()
        if key in self.pressed_keys:
            return
        self.pressed_keys.add(key)

        cmd = KEY_PRESS_COMMANDS.get(key)
        if cmd:
            self.send_command(cmd)

    def on_key_release(self, event: tk.Event) -> None:
        key = event.keysym.lower()
        self.pressed_keys.discard(key)

        cmd = KEY_RELEASE_COMMANDS.get(key)
        if cmd:
            self.send_command(cmd)

    # ---------- helpers ----------

    def log(self, message: str) -> None:
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {message}\n")
        self.log_text.see("end")

    def on_close(self) -> None:
        if self.settings_window and self.settings_window.winfo_exists():
            self.settings_window.destroy()
        self.disconnect()
        self.destroy()


def main() -> int:
    app = RobotXControlApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
