# Проверки комплекта v3.0

1. Nano — host C++ синтаксис: PASS (макеты Arduino/Servo/EEPROM/таймеров, не реальная прошивка).
2. Nano — тестовые сценарии: PASS (EEPROM CRC, формат CFG, COMMIT, сохранение, загрузка, границы, signed trim, команды V, медленный разгон, левый D8/D9, правый D5/D6, отсутствие 1/1 в проверенных состояниях, реверс через 0 и S).
3. ESP32-C3 — host C++ синтаксис: PASS (макеты Arduino-ESP32 WiFi/WebServer/Preferences, не реальная прошивка).
4. Web UI JavaScript — `node --check`: PASS.
5. Web UI JS — тест очереди команд, отпускания сервопривода и диапазонов формы: PASS.
6. Python GUI — `py_compile`: PASS.

НЕ проверено: сборка через Arduino IDE и реальный ESP32-C3/Arduino Nano, UART через 5В/3,3В согласователь, Wi-Fi и EEPROM на живом устройстве. Перед соревнованиями провести аппаратные тесты.
